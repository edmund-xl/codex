#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_DIR="${ROOT_DIR}/dist"
STAMP="$(date +%Y%m%d-%H%M%S)"
VERSION="$(cat "${ROOT_DIR}/VERSION")"
MANIFEST="${DIST_DIR}/release-manifest-${STAMP}.md"

required_files=(
  "README.md"
  "CHANGELOG.md"
  "VERSION"
  "SYSTEM_DESIGN.md"
  "FEATURE_SNAPSHOT.md"
  "REBUILD_GUIDE.md"
  "TRAINING_WORKFLOW.md"
  "PORTABLE_TRANSFER.md"
  "backup.sh"
  "start.sh"
  "stop.sh"
)

for file in "${required_files[@]}"; do
  if [ ! -f "${ROOT_DIR}/${file}" ]; then
    echo "Missing required release file: ${file}" >&2
    exit 1
  fi
done

mkdir -p "${DIST_DIR}"

"${ROOT_DIR}/.venv/bin/python" -m pytest -q

BACKUP_PATH="$("${ROOT_DIR}/backup.sh")"

{
  echo "# Release Manifest"
  echo
  echo "- Timestamp: ${STAMP}"
  echo "- Version: ${VERSION}"
  echo "- Root: ${ROOT_DIR}"
  echo "- Backup: ${BACKUP_PATH}"
  echo
  echo "## Included docs"
  for file in "${required_files[@]}"; do
    echo "- ${file}"
  done
  echo
  echo "## Data snapshot"
  find "${ROOT_DIR}/data" -maxdepth 1 -type f | sort | while read -r path; do
    bytes="$(wc -c < "${path}")"
    echo "- $(basename "${path}") : ${bytes} bytes"
  done
} > "${MANIFEST}"

echo "${MANIFEST}"
