# MegaETH AI Security Platform

这是当前可运行、可迁移、可继续训练的 MegaETH AI Security 工作副本。

目标：
- 统一接收安全材料
- 自动归一化、分类、规划分析能力、生成报告
- 通过 Memory 持续学习用户纠偏
- 保持可复制到其他机器直接运行
- 在目录丢失或损坏后，仍可依据文档由 AI 重建到接近一致的状态

## 当前目录结构

```text
megaeth-ai-security-rebuild/
├── app/
│   ├── api/          # FastAPI 路由
│   ├── core/         # pipeline / normalizer / planner / risk / report / memory
│   ├── models/       # 事件、发现、记忆数据模型
│   ├── skills/       # MegaETH skills 实现
│   ├── static/       # 前端页面、样式、交互逻辑
│   └── utils/        # 文件解析、JSON 存储
├── data/             # 本地事件、报告、调查、记忆数据
├── tests/            # 基础回归测试
├── README.md
├── CHANGELOG.md
├── VERSION
├── SYSTEM_DESIGN.md
├── FEATURE_SNAPSHOT.md
├── REBUILD_GUIDE.md
├── TRAINING_WORKFLOW.md
├── PORTABLE_TRANSFER.md
├── RELEASE_PROCESS.md
├── backup.sh
├── release.sh
├── start.sh
└── stop.sh
```

## 快速启动

```bash
cd '/Users/lei/Documents/New project/megaeth-ai-security-rebuild'
./start.sh
```

默认访问：

- [http://127.0.0.1:8010](http://127.0.0.1:8010)

如需改端口：

```bash
PORT=8011 ./start.sh
```

停止服务：

```bash
PORT=8010 ./stop.sh
```

## 推荐环境

- Python 3.13 优先
- Python 3.12 / 3.11 也可尝试
- 不建议直接使用 Python 3.14

## 文档索引

- 系统设计与架构：
  [SYSTEM_DESIGN.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/SYSTEM_DESIGN.md)
- 当前功能和 UI 快照：
  [FEATURE_SNAPSHOT.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/FEATURE_SNAPSHOT.md)
- 让 AI 重建同款系统：
  [REBUILD_GUIDE.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/REBUILD_GUIDE.md)
- 训练协作规范：
  [TRAINING_WORKFLOW.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/TRAINING_WORKFLOW.md)
- 跨机器迁移说明：
  [PORTABLE_TRANSFER.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/PORTABLE_TRANSFER.md)
- 发布与归档流程：
  [RELEASE_PROCESS.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/RELEASE_PROCESS.md)
- 版本变更：
  [CHANGELOG.md](/Users/lei/Documents/New%20project/megaeth-ai-security-rebuild/CHANGELOG.md)

## 当前能力范围

- 统一输入：文本输入 + 文件上传
- 文件类型：`csv / json / log / txt / yaml / yml / md / 文本型 pdf`
- 核心流程：`raw -> normalize -> planner -> skills -> risk -> report`
- 模块覆盖：
  - CI/CD
  - Endpoint
  - Host
  - Cloud
  - EASM
  - Key
  - Identity
- 历史沉淀：
  - raw events
  - normalized events
  - reports
  - investigations
  - memory rules
  - memory feedback
- 前端工作区：
  - Overview
  - Intake
  - Skills
  - Memory
- 中英文切换
- 刷新后保留当前页面
- 本地 Memory 学习与纠偏

## 备份与迁移

生成便携备份包：

```bash
./backup.sh
```

生成一次完整发布记录：

```bash
./release.sh
```

备份包会输出到：

- `dist/megaeth-ai-security-rebuild-backup-<timestamp>.tar.gz`

发布记录会输出到：

- `dist/release-manifest-<timestamp>.md`

备份会排除：

- `.venv`
- `__pycache__`
- `.pytest_cache`
- `dist`

## 重要说明

- `data/` 目录里的内容就是当前运行状态与学习记录。
- 如果你要把系统拷到别的机器继续使用，除了代码本身，`data/` 也应该一起带走。
- 如果你要在干净状态下测试，可以清空 `data/*.json`，但这会同时清掉历史与记忆。
