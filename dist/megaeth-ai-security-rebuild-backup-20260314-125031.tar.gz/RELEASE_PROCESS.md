# Release Process

这份文档定义的是：以后每次功能更新、报告训练、Memory 学习增强之后，怎么把这些变化同步进版本、文档和备份包。

## 目标

每次迭代后，都同步完成这 5 件事：

1. 代码更新
2. 文档更新
3. 版本号更新
4. 测试验证
5. 生成压缩备份包

## 每次更新后必须检查的内容

### A. 功能变化

如果新增或改变了这些内容，就必须更新文档：

- 新的页面结构
- 新的 API
- 新的分析路径
- 新的 Memory 行为
- 新的 skill / module
- 新的训练协作方式
- 新的跨机器运行方式

### B. 训练变化

如果新增了以下内容，也必须在本轮记录里说明：

- 新学会的报告类型
- 新修正的误判模式
- 新增的分类规则
- 新增的报告模板逻辑
- 新增的纠偏流程

## 需要同步更新的文件

### 一定要更新

- `CHANGELOG.md`
- `VERSION`

### 按内容更新

- `README.md`
- `SYSTEM_DESIGN.md`
- `FEATURE_SNAPSHOT.md`
- `REBUILD_GUIDE.md`
- `TRAINING_WORKFLOW.md`
- `PORTABLE_TRANSFER.md`

## 推荐工作流

每次功能做完后，按这个顺序执行：

```bash
cd '/Users/lei/Documents/New project/megaeth-ai-security-rebuild'
./.venv/bin/python -m pytest -q
./release.sh
```

## release.sh 应该做什么

1. 检查关键文档是否存在
2. 运行测试
3. 生成一个发布 manifest
4. 生成 clean backup 压缩包
5. 输出产物路径

## 发布产物

每次发布后，至少应有：

- 一个新的备份包
- 一个新的 manifest 文件

manifest 应该记录：

- 时间
- 版本号
- 文档列表
- 备份包路径
- data 文件状态

## 纪律要求

以后只要有“值得保留”的更新，就不要只改代码不留记录。

最低要求是：

- CHANGELOG 写一条
- VERSION 升一个小版本
- 跑测试
- 生成一次 release 产物
