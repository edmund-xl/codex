from unittest.mock import patch

from fastapi.testclient import TestClient

from app.main import app
from app.core.pipeline import SecurityPipeline


client = TestClient(app)


def test_health() -> None:
    assert client.get("/health").json() == {"status": "ok"}


def test_risk_analytics_csv_maps_to_host_pipeline() -> None:
    files = [
        (
            "files",
            (
                "megalabs_2026-03-13_riskanalytics.csv",
                (
                    "发现名称,风险评分,平台,合规标准\n"
                    "未安装 auditd,99,Unix,PCI DSS v4.0.1\n"
                    "SSH 访问未受限制,100,Unix,CIS v8.0\n"
                ).encode("utf-8"),
                "text/csv",
            ),
        ),
    ]
    body = client.post("/ingest/files", files=files).json()
    item = body["results"][0]
    assert item["normalized_event"]["source_type"] == "host"
    assert "megaeth.host.integrity_monitor" in item["report"]["skills_selected"]
    assert item["report"]["findings"]


def test_memory_learning_reclassifies_upload() -> None:
    payload = {
        "raw_event": {
            "source_type": "github",
            "asset_context": {
                "asset_id": "baseline",
                "asset_name": "baseline",
                "source_file": "riskanalytics-memory.csv",
            },
            "payload": {
                "headers": ["发现名称", "风险评分", "平台", "合规标准"],
                "rows": [{"发现名称": "未安装 auditd", "风险评分": "99", "平台": "Unix"}],
                "parser_profile": "csv-tabular",
            },
        },
        "expected_source_type": "host",
        "expected_event_type": "host_integrity",
        "preferred_skills": ["megaeth.host.integrity_monitor", "megaeth.host.systemd_service_risk"],
        "name": "Risk analytics memory",
    }
    assert client.post("/memory/learn/classification", json=payload).status_code == 200

    files = [
        (
            "files",
            (
                "riskanalytics-memory.csv",
                (
                    "发现名称,风险评分,平台,合规标准\n"
                    "SSH 访问未受限制,100,Unix,CIS v8.0\n"
                    "未安装 auditd,99,Unix,PCI DSS v4.0.1\n"
                ).encode("utf-8"),
                "text/csv",
            ),
        ),
    ]
    body = client.post("/ingest/files", files=files).json()
    item = body["results"][0]
    assert item["normalized_event"]["normalized_data"]["_memory_context"]["matched_rule_name"] == "Risk analytics memory"


def test_memory_rules_deduplicate_similar_manual_entries() -> None:
    payload = {
        "raw_event": {
            "source_type": "github",
            "asset_context": {
                "asset_id": "baseline",
                "asset_name": "baseline",
                "source_file": "dedupe-risk.csv",
            },
            "payload": {
                "headers": ["发现名称", "风险评分", "平台", "合规标准"],
                "rows": [{"发现名称": "未安装 auditd", "风险评分": "99", "平台": "Unix"}],
                "parser_profile": "csv-tabular",
            },
        },
        "expected_source_type": "host",
        "expected_event_type": "host_integrity",
        "preferred_skills": ["megaeth.host.integrity_monitor"],
    }
    assert client.post("/memory/learn/classification", json=payload).status_code == 200
    assert client.post("/memory/learn/classification", json=payload).status_code == 200
    rules = [item for item in client.get("/memory/rules").json() if item["expected_event_type"] == "host_integrity"]
    dedupe_rules = [item for item in rules if "dedupe-risk.csv" in item.get("filename_tokens", [])]
    assert len(dedupe_rules) == 1


def test_pdf_endpoint_material_maps_to_endpoint() -> None:
    files = [("files", ("incident.pdf", b"%PDF-1.7", "application/pdf"))]
    with patch("app.utils.file_ingest.extract_pdf_text", return_value="Attack.LocalFileInclusion.132 /.env endpoint shellspawned"):
        body = client.post("/ingest/files", files=files).json()
    assert body["results"][0]["normalized_event"]["source_type"] == "endpoint"


def test_pipeline_restores_overview_metrics_and_recent_reports_from_history() -> None:
    fake_report = {
        "event_id": "evt-1",
        "event_type": "host_integrity",
        "source_type": "host",
        "planner_reason": "restored",
        "skills_selected": ["megaeth.host.integrity_monitor"],
        "findings": [
            {
                "finding_id": "f-1",
                "skill_id": "megaeth.host.integrity_monitor",
                "risk_level": 4,
                "risk_label": "high",
                "risk_type": "integrity_change",
                "confidence": 0.84,
                "summary": "restored finding",
                "affected_assets": ["host-1"],
                "evidence": [],
                "recommendations": [],
            }
        ],
        "summary": "restored summary",
        "assessment": "restored assessment",
        "likely_issue": True,
        "verdict": "confirmed_posture_risk",
        "evidence_highlights": [],
        "recommended_actions": [],
        "analyst_notes": [],
        "key_facts": [],
        "probable_causes": [],
        "why_flagged": "",
        "report_gaps": [],
        "quick_checks": [],
        "escalation_conditions": [],
        "professional_judgment": "",
        "top_risk_level": 4,
        "top_risk_label": "high",
        "overall_risk_score": 4.2,
        "generated_at": "2026-03-14T10:00:00Z",
        "observability": {},
    }
    with patch("app.core.pipeline.HistoryService.list_reports", return_value=[fake_report]), patch(
        "app.core.pipeline.HistoryService.list_events", return_value=[]
    ):
        pipeline = SecurityPipeline()
    overview = pipeline.overview()
    assert overview["metrics"]["events_processed"] == 1
    assert overview["metrics"]["findings_generated"] == 1
    assert overview["metrics"]["last_event_at"] == "2026-03-14T10:00:00Z"
    assert pipeline.recent()[0]["event_id"] == "evt-1"
