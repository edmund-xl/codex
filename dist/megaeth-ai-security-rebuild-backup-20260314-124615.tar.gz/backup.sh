#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_DIR="${ROOT_DIR}/dist"
STAMP="$(date +%Y%m%d-%H%M%S)"
NAME="megaeth-ai-security-rebuild-backup-${STAMP}.tar.gz"

mkdir -p "${DIST_DIR}"

tar \
  --exclude=".venv" \
  --exclude="__pycache__" \
  --exclude=".pytest_cache" \
  --exclude="dist" \
  -czf "${DIST_DIR}/${NAME}" \
  -C "${ROOT_DIR}" .

echo "${DIST_DIR}/${NAME}"
