from __future__ import annotations

from typing import Any
from uuid import uuid4

from app.models.event import NormalizedEvent
from app.models.finding import Finding


def _risk_label(level: int) -> str:
    return {1: "info", 2: "low", 3: "medium", 4: "high", 5: "critical"}.get(level, "info")


class Skill:
    def __init__(self, skill_id: str, skill_name: str, category: str, description: str) -> None:
        self.skill_id = skill_id
        self.skill_name = skill_name
        self.category = category
        self.description = description

    def execute(self, event: NormalizedEvent) -> list[Finding]:
        data = event.normalized_data
        blob = " ".join(str(v).lower() for v in data.values())
        findings: list[Finding] = []
        if self.skill_id == "megaeth.cicd.pr_security_review" and any(token in blob for token in ("subprocess", "curl", "bash")):
            findings.append(self._finding(event, 4, "dangerous_code", "Potential dangerous execution flow found in supplied code or PR content."))
        elif self.skill_id == "megaeth.cicd.secret_detection" and any(token in blob for token in ("akia", "private key", "api_key", "secret")):
            findings.append(self._finding(event, 5, "secret_exposure", "Potential secret material detected in supplied content."))
        elif self.skill_id == "megaeth.endpoint.process_anomaly" and any(token in blob for token in ("attack.localfileinclusion", "/.env", "shellspawned", "credentialtheft")):
            findings.append(self._finding(event, 4, "endpoint_process", "Endpoint incident material contains suspicious process or exploit indicators."))
        elif self.skill_id == "megaeth.host.integrity_monitor":
            rows = data.get("rows", [])
            if isinstance(rows, list) and rows:
                severe = []
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    title = str(row.get("发现名称") or row.get("\ufeff发现名称") or "")
                    score = str(row.get("风险评分") or "0")
                    try:
                        if int(float(score)) >= 95:
                            severe.append(title)
                    except ValueError:
                        pass
                if severe:
                    findings.append(
                        self._finding(
                            event,
                            4,
                            "integrity_change",
                            f"Host hardening report contains {len(severe)} critical or near-critical control gaps across operating system baselines.",
                            evidence=[{"top_findings": severe[:5]}],
                            recommendations=[
                                "Prioritize filesystem, logging, and audit control gaps with risk scores above 95.",
                                "Deploy missing host integrity controls such as auditd and AIDE on affected Unix assets.",
                            ],
                        )
                    )
        elif self.skill_id == "megaeth.host.systemd_service_risk":
            rows = data.get("rows", [])
            service_findings = []
            if isinstance(rows, list):
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    title = str(row.get("发现名称") or row.get("\ufeff发现名称") or "")
                    if any(token in title.lower() for token in ("ssh", "telnet", "rsync", "icmp", "openssh", "rds", "printer")):
                        service_findings.append(title)
            if service_findings:
                findings.append(
                    self._finding(
                        event,
                        4,
                        "service_risk",
                        f"Network-facing service posture includes {len(service_findings)} risky exposure or remote-access control findings.",
                        evidence=[{"service_findings": service_findings[:6]}],
                        recommendations=[
                            "Tighten SSH exposure, legacy remote services, and insecure network control settings.",
                            "Validate that remote administration paths are restricted to approved management boundaries.",
                        ],
                    )
                )
        elif self.skill_id == "megaeth.cloud.config_audit" and any(token in blob for token in ("public bucket", "security group", "cloudtrail", "bucket")):
            findings.append(self._finding(event, 3, "cloud_misconfiguration", "Cloud posture issues suggest misconfiguration or missing controls."))
        elif self.skill_id == "megaeth.easm.service_scan" and any(token in blob for token in ("port", "service", "ssh", "http")):
            findings.append(self._finding(event, 3, "service_exposure", "Service exposure data indicates externally reachable services requiring review."))
        elif self.skill_id == "megaeth.key.kms_risk" and any(token in blob for token in ("sign", "kms", "caller")):
            findings.append(self._finding(event, 5, "kms_access", "KMS signing activity deviates from expected operational baseline."))
        return findings

    def _finding(
        self,
        event: NormalizedEvent,
        level: int,
        risk_type: str,
        summary: str,
        evidence: list[dict[str, Any]] | None = None,
        recommendations: list[str] | None = None,
    ) -> Finding:
        return Finding(
            finding_id=f"{event.event_id}-{self.skill_id}-{uuid4().hex[:8]}",
            skill_id=self.skill_id,
            risk_level=level,
            risk_label=_risk_label(level),
            risk_type=risk_type,
            confidence=0.84 if level >= 4 else 0.74,
            summary=summary,
            affected_assets=[str(event.asset_context.get("asset_name", "unknown"))],
            evidence=evidence or [],
            recommendations=recommendations or [],
        )


SKILLS = {
    "megaeth.cicd.pr_security_review": Skill("megaeth.cicd.pr_security_review", "PR Security Review", "cicd", "Reviews supplied code and change content."),
    "megaeth.cicd.secret_detection": Skill("megaeth.cicd.secret_detection", "Secret Detection", "cicd", "Detects exposed keys and secrets."),
    "megaeth.endpoint.process_anomaly": Skill("megaeth.endpoint.process_anomaly", "Endpoint Process Anomaly", "endpoint", "Analyzes endpoint incident material."),
    "megaeth.host.integrity_monitor": Skill("megaeth.host.integrity_monitor", "Host Integrity Monitor", "host", "Evaluates host baseline and integrity drift."),
    "megaeth.host.systemd_service_risk": Skill("megaeth.host.systemd_service_risk", "Service Risk Review", "host", "Reviews remote-access and service posture issues."),
    "megaeth.host.binary_tamper_review": Skill("megaeth.host.binary_tamper_review", "Binary Tamper Review", "host", "Reserved for binary integrity review."),
    "megaeth.cloud.config_audit": Skill("megaeth.cloud.config_audit", "Cloud Config Audit", "cloud", "Reviews cloud configuration drift."),
    "megaeth.easm.asset_discovery": Skill("megaeth.easm.asset_discovery", "Asset Discovery", "easm", "Processes asset inventory material."),
    "megaeth.easm.service_scan": Skill("megaeth.easm.service_scan", "Service Exposure", "easm", "Processes service exposure outputs."),
    "megaeth.easm.tls_analysis": Skill("megaeth.easm.tls_analysis", "TLS Analysis", "easm", "Reserved for TLS posture review."),
    "megaeth.key.kms_risk": Skill("megaeth.key.kms_risk", "KMS Risk", "key", "Reviews abnormal key usage."),
    "megaeth.key.private_key_exposure": Skill("megaeth.key.private_key_exposure", "Private Key Exposure", "key", "Detects exposed key material."),
    "megaeth.identity.policy_risk_analysis": Skill("megaeth.identity.policy_risk_analysis", "Policy Risk Analysis", "identity", "Analyzes policy sprawl and privilege risk."),
    "megaeth.identity.anomalous_access_review": Skill("megaeth.identity.anomalous_access_review", "Anomalous Access Review", "identity", "Reviews identity-driven access anomalies."),
    "megaeth.cloud.identity_surface": Skill("megaeth.cloud.identity_surface", "Cloud Identity Surface", "cloud", "Reviews cloud privilege surface."),
    "megaeth.easm.vulnerability_scan": Skill("megaeth.easm.vulnerability_scan", "Exposure Verification", "easm", "Processes vulnerability and exposure verification results."),
    "megaeth.easm.external_intelligence": Skill("megaeth.easm.external_intelligence", "External Intelligence", "easm", "Processes internet intelligence and exposure context."),
}
